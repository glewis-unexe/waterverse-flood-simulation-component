import sys
import time
import PIL
import PIL.Image
import pyproj
import unexecore.debug

def rgba2hex(color_rgba:tuple) -> str:
    return '#{:02x}{:02x}{:02x}'.format(*color_rgba)


def round_floats(o:object, post_dp:int=1):
    if isinstance(o, float):
        return round(o, post_dp)
    if isinstance(o, dict):
        return {k: round_floats(v, post_dp) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [round_floats(x,post_dp) for x in o]
    return o



def read_header(filename:str) -> dict:
    result = {}

    with (open(filename) as file):
        for i in range(0, 6):
            args = file.readline().split()

            if args[0] == 'ncols':
                result['ncols'] = int(args[1])

            if args[0] == 'nrows':
                result['nrows'] = int(args[1])

            if args[0] == 'xllcorner':
                if '.' in args[1]:
                    result['xllcorner'] = float(args[1])
                else:
                    result['xllcorner'] = int(args[1])

            if args[0] == 'yllcorner':
                if '.' in args[1]:
                    result['yllcorner'] = float(args[1])
                else:
                    result['yllcorner'] = int(args[1])

            if args[0] == 'cellsize':
                if '.' in args[1]:
                    result['cellsize'] = float(args[1])
                else:
                    result['cellsize'] = int(args[1])

            if args[0] == 'NODATA_value':
                if '.' in args[1]:
                    result['nodata'] = float(args[1])
                else:
                    result['nodata'] = int(args[1])


    return result


class ASCFile:
    def __init__(self, filename:str=None):

        self.ncols = 0
        self.nrows = 0
        self.xllcorner = 0.0
        self.yllcorner = 0.0
        self.cellsize = 0.0
        self.nodata = 0

        self.data = []

        if filename != None:
            self.load(filename)

    def save(self, filename:str):
        with open(filename,'w') as file:
            file.write('ncols ' + str(self.ncols) + '\n' )
            file.write('nrows ' + str(self.nrows) + '\n')
            file.write('xllcorner ' + str(self.xllcorner) + '\n')
            file.write('yllcorner ' + str(self.yllcorner) + '\n')
            file.write('cellsize ' + str(self.cellsize) + '\n')
            file.write('NODATA_value ' + str(self.nodata) + '\n')
            file.write('\n')

            for y in range(0, self.nrows):
                for x in range(0, self.ncols):
                    try:
                        file.write(str(self.data[y][x]) + ' ')
                    except Exception as e:
                        print(str(e))

                file.write('\n')
            file.write('\n')

    def load(self, filename:str):
        with (open(filename) as file):
            for i in range(0,6):
                args = file.readline().split()

                if args[0] == 'ncols':
                    self.ncols = int(args[1])

                if args[0] == 'nrows':
                    self.nrows = int(args[1])

                if args[0] == 'xllcorner':
                    if '.' in args[1]:
                        self.xllcorner = float(args[1])
                    else:
                        self.xllcorner = int(args[1])

                if args[0] == 'yllcorner':
                    if '.' in args[1]:
                        self.yllcorner = float(args[1])
                    else:
                        self.yllcorner = int(args[1])

                if args[0] == 'cellsize':
                    if '.' in args[1]:
                        self.cellsize = float(args[1])
                    else:
                        self.cellsize = int(args[1])

                if args[0] == 'NODATA_value':
                    if '.' in args[1]:
                        self.nodata = float(args[1])
                    else:
                        self.nodata = int(args[1])

            if self.ncols > 0 and self.nrows > 0:
                self.data = [self.nodata] * (self.nrows)

                y = 0

                values_read = 0

                while line := file.readline():
                    args = line.split()

                    if len(args) > 0:
                        if len(args) == self.ncols:
                            self.data[y] = [self.nodata] * (self.ncols)
                            x = 0
                            for val in args:
                                self.data[y][x] = float(val)
                                values_read += 1

                                x+= 1
                            y+=1
                        else:
                            raise Exception('error: short row: ' + str(len(args)) + ' vs. ' + str(self.ncols)  )

                if values_read != self.ncols * self.nrows:
                    raise Exception('error: data is short ' + str(values_read) + ' vs. ' + str(self.ncols * self.nrows))

    def save_to_png(self, filename:str):
        col = (255, 255, 255, 0)

        depth2col = {}

        new_data = [(0, 0, 0, 0)] * (self.nrows * self.ncols)

        y = 0
        colourLookup = {}
        colourLookup[0.1] = (255, 255, 255, 0)
        colourLookup[0.5] = (206, 236, 254, 255)
        colourLookup[1.0] = (156, 203, 254, 255)
        colourLookup[2.0] = (114, 153, 254, 255)
        colourLookup[4.0] = (69, 102, 254, 255)
        colourLookup[9999999.0] = (23, 57, 206, 255)

        keys = list(colourLookup.keys())

        while y < self.nrows:
            x = 0
            while x < self.ncols:
                v0 = self.data[y][x]

                if v0 not in depth2col:
                    if v0 == self.nodata:
                        col = colourLookup[keys[0]]
                    else:
                        for val in keys:
                            if v0 >= val:
                                col = colourLookup[val]

                    depth2col[v0] = col
                else:
                    col = depth2col[v0]

                new_data[(y * self.ncols) + x] = col

                x += 1

            y += 1

        im = PIL.Image.new(mode="RGBA", size=(int(self.ncols), int(self.nrows)))
        im.putdata(new_data)
        im = im.quantize(len(keys))

        im.save(filename)

    def point_in_me(self, point:list) ->bool:
        if point[0] < self.xllcorner: return False
        if point[1] < self.yllcorner: return False

        if point[0] > self.xllcorner + (self.ncols * self.cellsize): return False
        if point[1] > self.yllcorner + (self.nrows * self.cellsize): return False

        return True

    def get_data_WC(self, point:list) -> float:
        if self.point_in_me(point):
            col = int((point[0] - self.xllcorner) / float(self.cellsize))
            row = int((point[1] - self.yllcorner) / float(self.cellsize))

            row = int(self.nrows) - row - 1

            return self.get_data(col,row)

        raise Exception('not in range')

    def get_data(self, x:int, y:int) -> float:
        return self.data[y][x]

    def set_data(self, x:int, y:int, val:float):
        self.data[y][x] = val

    def to_geojson(self, src_crs: str, colourLookup: dict = None, label: str = '', attrib_label: str = 'value') -> dict:
        try:
            geojson = {
                "type": "FeatureCollection",
                "name": label,
                "crs": {
                    "type": "name",
                    "properties": {
                        "name": "ESPG:4326"
                    }
                },
                "features": []
            }

            if not colourLookup:
                colourLookup = {}
                colourLookup[0.1] = (255, 255, 255, 0)
                colourLookup[0.5] = (206, 236, 254, 255)
                colourLookup[1.0] = (156, 203, 254, 255)
                colourLookup[2.0] = (114, 153, 254, 255)
                colourLookup[4.0] = (69, 102, 254, 255)
                colourLookup[9999999.0] = (23, 57, 206, 255)

            keys = list(colourLookup.keys())
            keys.sort()

            transformer = pyproj.Transformer.from_crs(src_crs, 'EPSG:4326')

            for y in range(0, self.nrows):
                for x in range(0, self.ncols):
                    try:
                        v0 = self.data[y][x]

                        if v0 != self.nodata and v0 > keys[0]:
                            feature = {
                                "properties": {
                                    attrib_label: 0.0,
                                    "color": "#000000"
                                },
                                "geometry": {
                                    "type": "Polygon",
                                    "coordinates": []
                                },
                                "type": "Feature"
                            }
                            # make an edge loop [0,1,2,3,0]
                            # gareth: as this looks odd,
                            # llcorner is lower left, so y should increase to pole
                            # geojson needs top - offset to draw properly, so (nrows -y)
                            coords = [
                                [self.xllcorner + (x * self.cellsize), self.yllcorner + ((self.nrows - y) * self.cellsize)],
                                [self.xllcorner + ((x + 1) * self.cellsize), self.yllcorner + ((self.nrows - y) * self.cellsize)],
                                [self.xllcorner + ((x + 1) * self.cellsize), self.yllcorner + ((self.nrows - (y + 1)) * self.cellsize)],
                                [self.xllcorner + (x * self.cellsize), self.yllcorner + ((self.nrows - (y + 1)) * self.cellsize)],
                            ]

                            for c in range(0, len(coords)):
                                lat, lng = transformer.transform(coords[c][1], coords[c][0])
                                coords[c] = (lng, lat)

                            feature['geometry']['coordinates'].append(coords[0])
                            feature['geometry']['coordinates'].append(coords[1])
                            feature['geometry']['coordinates'].append(coords[2])
                            feature['geometry']['coordinates'].append(coords[3])
                            feature['geometry']['coordinates'].append(coords[0])

                            feature['geometry']['coordinates'] = [feature['geometry']['coordinates']]
                            feature['properties'][attrib_label] = float(v0)

                            for i in range(0, len(keys) - 1):
                                if v0 >= keys[i] and v0 < keys[i + 1]:
                                    feature['properties']['color'] = rgba2hex(colourLookup[keys[i + 1]])

                            geojson['features'].append(feature)
                    except Exception as e:
                        print(unexecore.debug.exception_to_string(e))

            return round_floats(geojson, 6)

        except Exception as e:
            print(unexecore.debug.exception_to_string(e))

        return {}


if __name__ == "__main__":
    filename = '/home/gareth/Documents/dev/digital_twin/data/eu-circle-project/Paignton/rain_100yr_2013/Param_WDrasterParam_9000.asc'

    ascfile = ASCFile()

    t0 = time.time()
    ascfile.load(filename)
    print('Load:' + str(time.time() - t0))

    t0 = time.time()
    ascfile.save_to_png('my.png')
    print('PNG:' + str(time.time() - t0))

    t0 = time.time()
    ascfile.save('test.asc')
    print('ASC:' + str(time.time() - t0))

