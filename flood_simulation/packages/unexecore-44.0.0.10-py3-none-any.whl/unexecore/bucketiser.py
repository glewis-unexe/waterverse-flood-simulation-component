
import sys
import os
import copy
import inspect

import unexecore.logger

class Bucketiser:
    def __init__(self, logger: unexecore.logger.Logger = None):
        self.logger = logger or unexecore.logger.Logger()
        self.bucket = None
        self.dp = 2

    # input_buckets is an array of {'date' == FIWARE_date}
    def create_buckets(self, input_buckets: list):
        self.bucket = copy.deepcopy(input_buckets)

        self.reset_buckets()

    def reset_buckets(self):
        for entry in self.bucket:
            entry['results'] = {}
            entry['results']['val'] = 0
            entry['results']['count'] = 0
            entry['results']['result'] = None
            entry['results']['min'] = sys.float_info.max
            entry['results']['max'] = sys.float_info.min

    def get_keys(self) -> list:
        result = []

        for entry in self.bucket:
            result.append(entry['date'])

        return result

    def get_values(self):
        result = []
        for entry in self.bucket:
            if entry['results']['count'] > 0:
                result.append(entry['results']['val'])
            else:
                result.append(None)

        return result

    def get_max(self) -> float:
        val = sys.float_info.min

        for entry in self.bucket:
            if entry['results']['count'] > 0 and entry['results']['val'] > val:
                val = entry['results']['val']

        return val

    def get_min(self) -> float:
        val = sys.float_info.max

        for entry in self.bucket:
            if entry['results']['count'] > 0 and entry['results']['val'] < val:
                val = entry['results']['val']

        return val

    def process_temporal_values(self, value_array: list, dp: int = 2):

        self.reset_buckets()
        bucket_index = 1
        value_index = 0
        date_index = 1

        for entry in value_array:
            bucket_index = 1

            try:
                if entry[date_index] < self.bucket[len(self.bucket) - 1]['date']:
                    while bucket_index < len(self.bucket) and (entry[date_index] >= self.bucket[bucket_index]['date']):
                        bucket_index += 1

                    if isinstance(entry[value_index], int) or isinstance(entry[value_index], float):
                        if self.bucket[bucket_index - 1]['results']['max'] < float(entry[value_index]):
                            self.bucket[bucket_index - 1]['results']['max'] = float(entry[value_index])

                        if self.bucket[bucket_index - 1]['results']['min'] > float(entry[value_index]):
                            self.bucket[bucket_index - 1]['results']['min'] = float(entry[value_index])

                        self.bucket[bucket_index - 1]['results']['val'] += entry[value_index]
                        self.bucket[bucket_index - 1]['results']['count'] += 1
                    else:
                        self.bucket[bucket_index - 1]['results']['val'] = entry[value_index]
            except Exception as e:
                if self.logger:
                    self.logger.exception(inspect.currentframe(), e)

        for entry in self.bucket:
            if entry['results']['count'] > 0:

                if isinstance(entry['results']['val'], int) or isinstance(entry['results']['val'], float):
                    entry['results']['result'] = round(entry['results']['val'] / entry['results']['count'], dp)
                    entry['results']['val'] = round(entry['results']['val'], dp)
        return self.bucket[:-1]

    def post_process(self):
        for entry in self.bucket:
            if entry['results']['count'] > 0:

                if isinstance(entry['results']['val'], int) or isinstance(entry['results']['val'], float):
                    entry['results']['result'] = round(entry['results']['val'] / entry['results']['count'], self.dp)
                    entry['results']['val'] = round(entry['results']['val'], self.dp)

        return self.bucket[:-1]

    def add_entry(self, timestamp, value):

        bucket_index = 1
        try:
            if timestamp < self.bucket[len(self.bucket) - 1]['date']:
                while bucket_index < len(self.bucket) and (timestamp >= self.bucket[bucket_index]['date']):
                    bucket_index += 1

                if isinstance(value, int) or isinstance(value, float):
                    if self.bucket[bucket_index - 1]['results']['max'] < float(value):
                        self.bucket[bucket_index - 1]['results']['max'] = float(value)

                    if self.bucket[bucket_index - 1]['results']['min'] > float(value):
                        self.bucket[bucket_index - 1]['results']['min'] = float(value)

                    self.bucket[bucket_index - 1]['results']['val'] += value
                    self.bucket[bucket_index - 1]['results']['count'] += 1
                else:
                    self.bucket[bucket_index - 1]['results']['val'] = value
        except Exception as e:
            if self.logger:
                self.logger.exception(inspect.currentframe(), e)