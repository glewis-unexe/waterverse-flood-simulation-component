import os
import traceback
class TestHarness:
    def __init__(self):
        self.options = {}
        self.title = 'ADD TITLE HERE'
    def run(self):
        quitApp = False

        while quitApp is False:
            print()
            print(self.title)
            print()

            for entry in self.options:
                print(entry.ljust(5,'.') + self.options[entry]['label'])


            print('xx'.ljust(5,'.') + 'Back')
            print('\n')

            try:
                key = input('>')

                if key in self.options:
                    if 'function' in self.options[key]:
                        if 'args' in self.options[key]:
                            self.options[key]['function'](self.options[key]['args'])
                        else:
                            self.options[key]['function']()

                if key == 'xx':
                    quitApp = True
            except Exception as e:
                print(str(e))