import traceback
import os
import inspect


def formatmsg(cf, msg):
    try:
        frameinfo = inspect.getframeinfo(cf)
        filename = frameinfo.filename.split('/')[-1]

        return (frameinfo.function + '() ' + filename + '-' + str(frameinfo.lineno) + ': ' + msg)
    except Exception as e:
        print(str(e))

def get_file_and_lineno(cf):
    try:
        frameinfo = inspect.getframeinfo(cf)
        #filename = frameinfo.filename.split('/')[-1]

        return frameinfo.filename + '-' + str(frameinfo.lineno)
    except Exception as e:
        print(str(e))

def get_filename_and_lineno(cf):
    try:
        frameinfo = inspect.getframeinfo(cf)
        return os.path.basename(frameinfo.filename) + '-' + str(frameinfo.lineno)
    except Exception as e:
        print(str(e))


class Logger:
    def __init__(self):
        pass

    def exception_to_string(self,exception):
        try:
            text = str(exception)
            text += '\n'
            stack = traceback.format_tb(tb=exception.__traceback__)
            stack.reverse()
            for entry in stack:
                terms = entry.split(',')
                head, filename = os.path.split(terms[0])
                text += filename.replace('"', '') + terms[1].replace('line ', ':').replace(' ', '')
                text += terms[2].replace('\n', '')
                text += '\n'

            return text

        except Exception as e:
            return 'Failed to process exception!'


    def exception(self, cf, exception):
        try:
            text = self.exception_to_string(exception)
            self.fail(cf,text)
        except Exception as e:
            self.fail(cf, 'Failed to process exception!')

    def fail(self, cf, text):
        self.log(cf, 'FAIL:'+str(text))

    def log(self, cf, text):
        print(self.formatmsg(cf, text))

    def formatmsg(self, cf, text):
        if cf is not None:
            return formatmsg(cf, str(text))

        return str(text)

    def set_time_callback(self, time_fn):
        pass


logger = Logger()