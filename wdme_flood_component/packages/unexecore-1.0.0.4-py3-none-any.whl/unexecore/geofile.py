import copy
import json

import rasterio
import pyproj
import unexecore.debug
import PIL
import PIL.Image
import jenkspy
import numpy
from rasterio.features import shapes

def value_to_index(breaks:list, value:float) -> int:
    i=0

    if breaks is not None:
        while breaks[i] < value:
            i+=1

    return i

def geojsonise(image, transform, crs:str=None) -> dict:
    mask = None
    results = (
        {'properties': {'raster_val': v}, 'geometry': s}
        for i, (s, v)
        in enumerate(
        shapes(image, mask=mask, transform=transform)))

    geojson = {}
    geojson["type"] = "FeatureCollection"
    geojson["name"] = "geojson name"

    if crs is not None:
        geojson["crs"] = {'type': "name", 'properties': {'name': crs}}

    geojson["features"] = list(results)

    final_features = []

    for feature in geojson['features']:
        if feature['properties']['raster_val'] > 0:
            final_features.append(feature)

    geojson['features'] = final_features

    for feature in geojson['features']:
        feature['type'] = 'feature'

    return geojson

def rgba2hex(color_rgba:tuple) -> str:
    return '#{:02x}{:02x}{:02x}'.format(*color_rgba)

class GeoFile:
    def __init__(self):
        self.raster_file = None
        self.nodata = 0

    def loadASC(self,filename:str) -> bool:
        self.raster_file = rasterio.open(filename, 'r+')

    def loadTIF(self,filename:str) -> bool:
        self.raster_file = rasterio.open(filename, 'r+')
        
    def getCSR(self):
        if self.raster_file != None and self.raster_file.crs != None:
            return self.raster_file.crs.data['init']
            
        return None

    def get_extents(self, target_crs:str="EPSG:4326", src_crs:str=None, flip_coords:bool=False) -> dict:
        extents = {}

        coord_order = [0,1]

        if flip_coords:
            coord_order = [1,0]

        try:
            if src_crs == None:
                src_crs = self.getCSR();

            transformer = pyproj.Transformer.from_crs(src_crs, target_crs)

            no_cols = self.raster_file.width
            no_rows = self.raster_file.height
            xllcorner = int(self.raster_file.bounds.left)
            yllcorner = int(self.raster_file.bounds.bottom)
            cellsize = self.raster_file.res[0]

            extents['bl'] = [xllcorner, yllcorner]
            extents['br'] = [xllcorner + (no_cols) * cellsize, yllcorner]
            extents['tl'] = [xllcorner, yllcorner + (no_rows) * cellsize]
            extents['tr'] = [xllcorner + (no_cols) * cellsize, yllcorner + (no_rows - 1) * cellsize]

            extents['tl'] = transformer.transform(extents['tl'][coord_order[0]], extents['tl'][coord_order[1]])
            extents['tr'] = transformer.transform(extents['tr'][coord_order[0]], extents['tr'][coord_order[1]])
            extents['bl'] = transformer.transform(extents['bl'][coord_order[0]], extents['bl'][coord_order[1]])
            extents['br'] = transformer.transform(extents['br'][coord_order[0]], extents['br'][coord_order[1]])
        except Exception as e:
            print(unexecore.debug.exception_to_string(e))

        return extents

    def get_png(self, colour_lookup:dict=None) -> PIL.Image:

        if colour_lookup is None:
            colour_lookup = {}
            colour_lookup[0.0] = (255, 255, 255, 0)
            colour_lookup[0.001] = (255, 255, 0, 255)
            colour_lookup[1.0] = (255, 0, 0, 255)
            colour_lookup[10.0] = (0, 255, 0, 255)
            colour_lookup[20.0] = (0, 0, 255, 255)

            colour_lookup[9999999.0] = (27, 79, 114, 255)

        keys = list(colour_lookup.keys())

        band1 = self.raster_file.read(1)

        im = PIL.Image.new(mode="RGBA", size=(int(self.raster_file.width), int(self.raster_file.height)))

        col = (255, 255, 255, 0)

        depth2col = {}

        for y in range(0, self.raster_file.height):
            for x in range(0, self.raster_file.width):
                try:
                    v0 = band1[y, x]

                    if v0 not in depth2col:
                        if v0 == self.raster_file.nodata:
                            col = colour_lookup[keys[0]]
                        else:
                            for val in keys:
                                if v0 >= val:
                                    col = colour_lookup[val]

                        depth2col[v0] = col
                    else:
                        col = depth2col[v0]

                    im.putpixel((x, y), col)

                except Exception as e:
                    print(unexecore.debug.exception_to_string(e))

        return im

    def get_png_build_lookup(self, classes=6)-> PIL.Image:

        band1 = self.raster_file.read(1)

        data = []
        for y in range(0, self.raster_file.height):
            for x in range(0, self.raster_file.width):

                if self.raster_file.nodata == None:
                    data.append(band1[y, x])
                else:
                    if self.raster_file.nodata != band1[y, x]:
                        data.append(band1[y, x])

        classes = min(len(numpy.unique(data)), classes)

        try:
            breaks = jenkspy.jenks_breaks(data,classes)

            colour_lookup = {}
            colour_lookup[0.0] = (255, 255, 255, 0)
            for index in range(0, len(breaks)):
                i = int((index*255)/float(len(breaks)))
                colour_lookup[breaks[index]] = (i, i, i, 255)

            return self.get_png(colour_lookup)

        except Exception as e:
            print(unexecore.debug.exception_to_string(e))

        return None

    def get_breaks(self, classes=6):
        band1 = self.raster_file.read(1)

        data = []
        for y in range(0, self.raster_file.height):
            for x in range(0, self.raster_file.width):

                if self.raster_file.nodata == None:
                    data.append(band1[y, x])
                else:
                    if self.raster_file.nodata != band1[y, x]:
                        data.append(band1[y, x])

        classes = min(len(numpy.unique(data)), classes)

        try:
            return jenkspy.jenks_breaks(data, classes)
        except Exception as e:
            print(unexecore.debug.exception_to_string(e))

        return None

    def get_raw_geojson(self, crs:str= None) -> dict:
        image = copy.deepcopy(self.raster_file.read(1) )
        geojson = geojsonise(image, self.raster_file.transform, crs)

        return geojson

    def get_geojson_from_colormap(self, colour_lookup:dict=None, crs:str=None) -> dict:

        image = copy.deepcopy(self.raster_file.read(1) )


        if colour_lookup:
            keys = list(colour_lookup.keys())

            for y in range(0, self.raster_file.height):
                for x in range(0, self.raster_file.width):
                    try:
                        image[y,x] = value_to_index(keys, image[y, x])
                    except Exception as e:
                        print(unexecore.debug.exception_to_string(e))

        else:
            i = 1

            for y in range(0, self.raster_file.height):
                for x in range(0, self.raster_file.width):
                    image[y,x] = i
                    i += 1

        geojson = geojsonise(image,self.raster_file.transform, crs)

        for feature in geojson['features']:
            if feature['properties']['raster_val'] > 0:
                if colour_lookup:
                    feature['properties']['color'] = rgba2hex(colour_lookup[ keys[int(feature['properties']['raster_val']) ] ])

        return geojson

    def get_geojson(self, classes:int=6, crs:str=None) -> dict:
        mask = None
        image = self.raster_file.read(1)  # first band

        if classes > 0:
            breaks = self.get_breaks(classes)

            for y in range(0, self.raster_file.height):
                for x in range(0, self.raster_file.width):
                    image[y, x] = value_to_index(breaks, image[y, x])

        results = (
            {'properties': {'raster_val': v}, 'geometry': s}
            for i, (s, v)
            in enumerate(
                shapes(image, mask=mask, transform=self.raster_file.transform)))

        geojson = {}
        geojson["type"] = "FeatureCollection"
        geojson["name"] = "geojson name"

        if crs != None:
            geojson["crs"] = {'type': "name", 'properties': {'name': crs}}
        else:
            geojson["crs"] = {'type': "name", 'properties': {'name': self.getCSR()}}

        geojson["features"] = list(results)

        final_features = []

        for feature in geojson['features']:
            if feature['properties']['raster_val'] > 0:
                final_features.append(feature)

        geojson['features'] = final_features

        for feature in geojson['features']:
            feature['type'] = 'feature'

        return geojson