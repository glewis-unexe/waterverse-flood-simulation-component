import os
def buildfilepath(path):
    path = os.path.normpath(path)
    folders = path.split(os.sep)

    file_path = folders[0] +os.sep

    for i in range(1, len(folders)):
        file_path += folders[i] +os.sep

        if not os.path.exists(file_path):
            os.mkdir(file_path)


import os, shutil
def deltree(path:str):
    for filename in os.listdir(path):
        file_path = os.path.join(path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            pass